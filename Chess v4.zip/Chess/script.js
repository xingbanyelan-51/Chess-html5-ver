var i18n = {
    zh: {
        fullscreen: '全屏',
        exitFullscreen: '退出全屏',
        undo: '悔棋',
        undoAll: '全部悔棋',
        searchTime: '思考时间:',
        nodesSearched: '搜索节点:',
        nodesPerSecond: '每秒搜索节点:',
        actualCalcTime: '实际计算时间:',
        gameState: '游戏状态:',
        newGame: '再来一局',
        playing: '对弈中',
        blackCheckmate: '黑方将杀',
        whiteCheckmate: '白方将杀',
        stalemate: '逼和',
        gameOver: '游戏已结束',
        invincible: '无敌模式',
        takeoverThinkTime: '接管思考时间:',
        engineTakeover: '引擎接管',
        moveHistory: '走棋记录'
    },
    en: {
        fullscreen: 'Fullscreen',
        exitFullscreen: 'Exit',
        undo: 'Undo',
        undoAll: 'Undo All',
        searchTime: 'Think time:',
        nodesSearched: 'Nodes searched:',
        nodesPerSecond: 'Nodes/s:',
        actualCalcTime: 'Actual time:',
        gameState: 'Game State:',
        newGame: 'New Game',
        playing: 'Playing',
        blackCheckmate: 'Black checkmate',
        whiteCheckmate: 'White checkmate',
        stalemate: 'Stalemate',
        gameOver: 'Game over',
        invincible: 'Invincible Mode',
        takeoverThinkTime: 'Takeover time:',
        engineTakeover: 'Engine Takeover',
        moveHistory: 'Move History'
    }
};

var lang = (navigator.language === 'zh' || navigator.language === 'zh-CN' || navigator.language === 'zh-TW') ? 'zh' : 'en';

function t(key) {
    return i18n[lang][key] || key;
}

var board,
    game = new Chess(),
    engineThinking = false,
    engineThinkingRequestId = 0;

var stockfishReady = false;
var bestMoveCallback = null;

window._sfMod.ready.then(function() {
    stockfishReady = true;
    window._sfMod.listener = function(line) {
        if (line === 'uciok') {
            window._sfMod.ccall('command', null, ['string'], ['isready']);
        }
        if (line === 'readyok') {
            stockfishReady = true;
        }
        if (line.startsWith('info') && line.indexOf(' nodes ') !== -1) {
            var parts = line.split(' ');
            for (var i = 0; i < parts.length; i++) {
                if (parts[i] === 'nodes' && i + 1 < parts.length) {
                    $('#node-count').text(parseInt(parts[i + 1]).toLocaleString());
                }
                if (parts[i] === 'time' && i + 1 < parts.length) {
                    var timeMs = parseInt(parts[i + 1]);
                    $('#time').text((timeMs / 1000).toFixed(2) + 's');
                }
                if (parts[i] === 'nps' && i + 1 < parts.length) {
                    $('#nodes-per-second').text(parseInt(parts[i + 1]).toLocaleString('en-US'));
                }
            }
        }
        if (line.startsWith('bestmove')) {
            var parts = line.split(' ');
            var bestmove = parts[1];
            if (bestMoveCallback) {
                var cb = bestMoveCallback;
                bestMoveCallback = null;
                engineThinking = false;
                cb(bestmove);
            }
        }
    };
    window._sfMod.ccall('command', null, ['string'], ['uci']);
});

var stopEngine = function() {
    engineThinkingRequestId++;
    engineThinking = false;
    bestMoveCallback = null;
    if (typeof window._sfMod !== 'undefined' && stockfishReady) {
        try {
            window._sfMod.ccall('command', null, ['string'], ['stop']);
        } catch (e) {}
    }
};

var canUndo = function() {
    var history = game.history();
    if (history.length === 0) return false;
    if (engineThinking) return false;
    return true;
};

var updateUndoButtons = function() {
    var enabled = canUndo();
    $('#undo-btn').prop('disabled', !enabled).css('opacity', enabled ? 1 : 0.5);
    var allEnabled = enabled && game.history().length >= 2;
    $('#undo-all-btn').prop('disabled', !allEnabled).css('opacity', allEnabled ? 1 : 0.5);
};

var syncBoard = function() {
    board.position(game.fen());
    updateUndoButtons();
    updateMoveHistory();
};

var updateMoveHistory = function() {
    var history = game.history({ verbose: true });
    var $list = $('#move-history-list');
    $list.empty();
    for (var i = 0; i < history.length; i += 2) {
        var moveNum = Math.floor(i / 2) + 1;
        var whiteMove = history[i].san;
        var blackMove = (i + 1 < history.length) ? history[i + 1].san : '';
        var $row = $('<div class="move-row"></div>');
        $row.append('<span class="move-num">' + moveNum + '.</span>');
        $row.append('<span class="move-white">' + whiteMove + '</span>');
        if (blackMove) {
            $row.append('<span class="move-black">' + blackMove + '</span>');
        }
        $list.append($row);
    }
    $list.scrollTop($list[0].scrollHeight);
};

var checkGameStatus = function() {
    if (game.in_checkmate()) {
        var winner = game.turn() === 'w' ? t('blackCheckmate') : t('whiteCheckmate');
        $('#game-state').text(winner);
        $('#new-game-btn').show();
        return true;
    }
    if (game.in_stalemate()) {
        $('#game-state').text(t('stalemate'));
        $('#new-game-btn').show();
        return true;
    }
    if (game.in_draw()) {
        $('#game-state').text(t('stalemate'));
        $('#new-game-btn').show();
        return true;
    }
    $('#game-state').text(t('playing'));
    $('#new-game-btn').hide();
    return false;
};

var onDragStart = function (source, piece, position, orientation) {
    if (game.in_checkmate() === true || game.in_draw() === true ||
        piece.search(/^b/) !== -1 || engineThinking) {
        return false;
    }
};

var makeBestMove = function () {
    if (game.game_over()) return;
    if (!stockfishReady) {
        window.setTimeout(makeBestMove, 100);
        return;
    }

    var fen = game.fen();
    var movetime = parseInt($('#search-time').val());
    var requestId = ++engineThinkingRequestId;

    engineThinking = true;
    updateUndoButtons();

    bestMoveCallback = function(uciMove) {
        if (requestId !== engineThinkingRequestId) return;
        if (!uciMove || uciMove === '(none)') return;

        var from = uciMove.substring(0, 2);
        var to = uciMove.substring(2, 4);
        var promotion = uciMove.length > 4 ? uciMove.substring(4, 5) : undefined;

        var move = game.move({
            from: from,
            to: to,
            promotion: promotion || 'q'
        });

        if (!move) return;

        syncBoard();
        $('#hint-text').text('');
        checkGameStatus();
    };

    window._sfMod.ccall('command', null, ['string'], ['position fen ' + fen]);
    window._sfMod.ccall('command', null, ['string'], ['go movetime ' + movetime], {async: true});
};

var onDrop = function (source, target) {
    var move = game.move({
        from: source,
        to: target,
        promotion: 'q'
    });

    if (move === null) {
        return 'snapback';
    }

    syncBoard();
    $('#hint-text').text('');
    $('#nodes-per-second').text('');
    if (checkGameStatus()) {
        return;
    }
    window.setTimeout(makeBestMove, 250);
};

var onSnapEnd = function () {
    board.position(game.fen());
};

var cfg = {
    draggable: true,
    position: 'start',
    onDragStart: onDragStart,
    onDrop: onDrop,
    onSnapEnd: onSnapEnd
};
board = ChessBoard('board', cfg);

$('#search-time').on('change', function() {
    $('#time-value').text($(this).find('option:selected').text());
});

function initI18n() {
    $('#undo-btn').text(t('undo'));
    $('#undo-all-btn').text(t('undoAll'));
    $('#search-time-label').text(t('searchTime'));
    $('#nodes-evaluated-label').text(t('nodesSearched'));
    $('#nodes-per-second-label').text(t('nodesPerSecond'));
    $('#time-label').text(t('actualCalcTime'));
    $('#game-state-label').text(t('gameState'));
    $('#new-game-btn').text(t('newGame'));
    $('#invincible-btn').text(t('invincible'));
    $('#takeover-think-time-label').text(t('takeoverThinkTime'));
    $('#engine-takeover-btn').text(t('engineTakeover'));
    $('#move-history-label').text(t('moveHistory'));
    initFullscreenBtn();
}

var fullscreenSvgEnter = '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#5D4037" stroke-width="2"><path d="M8 3H5a2 2 0 0 0-2 2v3m18 0V5a2 2 0 0 0-2-2h-3m0 18h3a2 2 0 0 0 2-2v-3M3 16v3a2 2 0 0 0 2 2h3"/></svg>';
var fullscreenSvgExit = '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#5D4037" stroke-width="2"><path d="M8 3v3a2 2 0 0 1-2 2H3m18 0h-3a2 2 0 0 1-2-2V3m0 18v-3a2 2 0 0 1 2-2h3M3 16h3a2 2 0 0 1 2 2v3"/></svg>';
var fullscreenClickCount = 0;

function initFullscreenBtn() {
    $('#fullscreen-btn').html(fullscreenSvgEnter).attr('title', t('fullscreen'));
}

$('#fullscreen-btn').on('click', function() {
    fullscreenClickCount++;
    if (fullscreenClickCount % 2 === 1) {
        document.documentElement.requestFullscreen();
        $('#fullscreen-btn').html(fullscreenSvgExit).attr('title', t('exitFullscreen'));
    } else {
        document.exitFullscreen();
        $('#fullscreen-btn').html(fullscreenSvgEnter).attr('title', t('fullscreen'));
    }
});

document.addEventListener('fullscreenchange', function() {
    if (document.fullscreenElement) {
        fullscreenClickCount = 1;
        $('#fullscreen-btn').html(fullscreenSvgExit).attr('title', t('exitFullscreen'));
    } else {
        fullscreenClickCount = 0;
        $('#fullscreen-btn').html(fullscreenSvgEnter).attr('title', t('fullscreen'));
    }
});

var performUndo = function(movesToUndo) {
    stopEngine();
    var history = game.history();
    var actualUndo = Math.min(movesToUndo, history.length);
    if (actualUndo === 0) return;

    for (var i = 0; i < actualUndo; i++) {
        game.undo();
    }

    if (game.turn() === 'b' && game.history().length > 0) {
        game.undo();
    }

    syncBoard();
    checkGameStatus();
};

$('#undo-btn').on('click', function() {
    if (!canUndo()) return;
    performUndo(1);
});

$('#undo-all-btn').on('click', function() {
    if (!canUndo()) return;
    performUndo(999);
});

$(document).on('keydown', function(e) {
    if ((e.ctrlKey || e.metaKey) && e.key === 'z') {
        e.preventDefault();
        if (canUndo()) {
            performUndo(1);
        }
    }
});

$('#engine-takeover-btn').on('click', function() {
    if (game.game_over()) return;
    if (!stockfishReady) return;
    if (game.turn() !== 'w') return;
    if (engineThinking) return;

    var fen = game.fen();
    var movetime = parseInt($('#takeover-time').val());
    var requestId = ++engineThinkingRequestId;

    engineThinking = true;
    updateUndoButtons();

    var takeoverCallback = function(uciMove) {
        if (requestId !== engineThinkingRequestId) return;
        bestMoveCallback = null;

        if (!uciMove || uciMove === '(none)') return;

        var from = uciMove.substring(0, 2);
        var to = uciMove.substring(2, 4);
        var promotion = uciMove.length > 4 ? uciMove.substring(4, 5) : undefined;

        var move = game.move({
            from: from,
            to: to,
            promotion: promotion || 'q'
        });

        if (!move) return;

        syncBoard();
        $('#hint-text').text('');
        if (!checkGameStatus()) {
            window.setTimeout(makeBestMove, 250);
        }
    };

    window._sfMod.ccall('command', null, ['string'], ['stop']);
    window._sfMod.ccall('command', null, ['string'], ['position fen ' + fen]);
    window._sfMod.ccall('command', null, ['string'], ['go movetime ' + movetime], {async: true});

    bestMoveCallback = takeoverCallback;
});

$('#invincible-btn').on('click', function() {
    stopEngine();
    var fen = game.fen();
    var parts = fen.split(' ');
    var rows = parts[0].split('/');
    for (var r = 0; r < rows.length; r++) {
        var newRow = '';
        for (var c = 0; c < rows[r].length; c++) {
            var ch = rows[r][c];
            if (ch !== 'K' && ch >= 'A' && ch <= 'Z') {
                newRow += 'Q';
            } else {
                newRow += ch;
            }
        }
        rows[r] = newRow;
    }
    parts[0] = rows.join('/');
    var turn = parts[1] || 'w';
    var newFen = parts[0] + ' ' + turn + ' - - 0 1';
    if (game.load(newFen)) {
        syncBoard();
        if (game.in_checkmate()) {
            var winner = game.turn() === 'w' ? t('blackCheckmate') : t('whiteCheckmate');
            $('#game-state').text(winner);
            $('#new-game-btn').show();
        } else if (game.in_stalemate()) {
            $('#game-state').text(t('stalemate'));
            $('#new-game-btn').show();
        } else {
            $('#game-state').text(t('playing'));
            $('#new-game-btn').hide();
        }
        $('#invincible-btn').prop('disabled', true).css('opacity', 0.5);
    }
});

$('#new-game-btn').on('click', function() {
    stopEngine();
    game = new Chess();
    board.position('start');
    $('#game-state').text(t('playing'));
    $('#new-game-btn').hide();
    $('#node-count').text('');
    $('#time').text('');
    $('#nodes-per-second').text('');
    $('#hint-text').text('');
    $('#invincible-btn').prop('disabled', false).css('opacity', 1);
    syncBoard();
});

initI18n();
$('#new-game-btn').hide();
$('#game-state').text(t('playing'));
syncBoard();
